# CTI-110
# P4HW1 - Score List
# Your Name
# Date
#print('Enter 5 scores: ')
scores = []
print('Enter number of scores')
num_scores = int(input())
scores = []
for i in range(num_scores):
    score = int(input(f'Enter score {i+1}: '))
    while score < 0 or score > 100:
        print('Invalid score. Please enter a score between 0 and 100.')
        score = int(input(f'Enter score {i+1}: '))
    scores.append(score)

min_score = min(scores)

print("-------results-----")
print(f'lowest score is {min_score}')
scores.remove(min_score)
print(f'modified list {scores}')



total_score = sum(scores)
average = total_score / len(scores)
if average >= 90:
    print("Your letter grade is: A")
elif average >= 80:
    print("Your letter grade is: B")
elif average >= 70:
    print("Your letter grade is: C")
elif average >= 60:
    print("Your letter grade is: D")
else:
    print("Your letter grade is: F")
print("Your average is:", average)

print("------------")